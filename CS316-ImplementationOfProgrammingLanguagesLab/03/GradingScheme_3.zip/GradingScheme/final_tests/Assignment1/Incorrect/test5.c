int a;

main ()
{
  int b;
  b = a;
  int a;
  a = 3;
}