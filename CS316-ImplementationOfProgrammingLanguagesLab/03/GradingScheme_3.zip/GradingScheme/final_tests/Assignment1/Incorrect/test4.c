void main();

main(){
  int main;
  
  main = 10;
 }