void main();
main()
{
	int a;
	a = 3;
	a = (-a) - 3 - -a - -a - 4 - (-a - (-a));
}