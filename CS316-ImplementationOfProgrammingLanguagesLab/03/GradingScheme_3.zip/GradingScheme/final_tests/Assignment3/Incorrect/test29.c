void main();

main()
{
	int a = 2;
	int b;
	b = +a;
	b = -+a;
	b = +-a;
}
