void main();

main()
{
	int i1, i2, i3, i4, i5;
	i1 = 1;
	i2 = 2;
	i3 = 3;
	i4 = 4;
	i5 = 5;	
	i1 = i1-i2*i3+i4/i5 - (i1<3);
}
