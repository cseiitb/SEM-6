void main();

main()
{
	int i,a,b,d;
	i = 1;
	a = 5;
	b = 6;
	d = 7;	
	while(i && i<6){
		
	}

}
