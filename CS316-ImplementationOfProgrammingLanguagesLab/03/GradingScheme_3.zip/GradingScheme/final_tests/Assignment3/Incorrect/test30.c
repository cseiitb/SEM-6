int a;
void main();

main(){
	int a,a,a;
}
