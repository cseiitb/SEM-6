void main();

main()
{
   int p;
   float z, y, x;

   x = 8.00;
   y = 911.01;
   p = 32;
   z = x + y - p * x;
   p = (y / x / z);
}
