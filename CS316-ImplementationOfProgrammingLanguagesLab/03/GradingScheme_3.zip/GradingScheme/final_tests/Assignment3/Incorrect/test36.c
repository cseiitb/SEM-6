void main();

main()

{

  {};

}
