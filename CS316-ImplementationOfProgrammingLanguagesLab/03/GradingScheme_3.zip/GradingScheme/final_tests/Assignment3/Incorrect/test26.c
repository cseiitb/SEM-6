void main();

main()
{
   int c;
   int b;
   int a;

   a = 4;
   b = 5;
   c = a + -1;
   if(a + b != 0.0)
   {
      if(a - 1.20 != 0.00){}
   }
}
