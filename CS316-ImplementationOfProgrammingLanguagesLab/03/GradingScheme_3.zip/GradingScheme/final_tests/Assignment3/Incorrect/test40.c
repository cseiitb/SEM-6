void main();

main(){
  int a;
  float b;
  a = a + (a < 1)?a:b;
}
