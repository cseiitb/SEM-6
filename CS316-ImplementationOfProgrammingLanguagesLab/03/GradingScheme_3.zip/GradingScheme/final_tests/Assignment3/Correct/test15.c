void main();

main ()
{
	int i;
	float f;
	
	i = 4;
	i = i>2 ? i-i*i : i/i+i;
}
