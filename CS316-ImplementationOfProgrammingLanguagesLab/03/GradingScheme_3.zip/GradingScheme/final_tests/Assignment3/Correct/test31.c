int a;
void main();

main(){
	int a,b,c;
}
