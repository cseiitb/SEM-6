void main();
	
main()
{
float a,b;
a = 6.0; b = 3.0;

a=a-b;
b=a+b;
a=b-a;
}
