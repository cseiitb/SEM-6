void main(); 

main()

{

   int a;

   int b;

   a = (a + b) + (a + b);
   a = a + b + a + b;
}

