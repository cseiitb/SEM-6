void main();

main ()
{
	int i;
	float f;
	
	if (i < i + i / 2) i = i;
	else{
		if (i + i >= i) f = f;
		else{
			if ((i>3) && (i<2)) i = i+i;
			else	f = f;
		}
	}	
}
