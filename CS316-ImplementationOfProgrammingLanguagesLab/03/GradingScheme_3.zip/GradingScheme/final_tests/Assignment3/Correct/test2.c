void main();

main()
{
   int n;
   int cntr;
   n = 3;
 
   if ( (n/2)*2 == n )	
      cntr = 1;
   else
      cntr = 0;
}
