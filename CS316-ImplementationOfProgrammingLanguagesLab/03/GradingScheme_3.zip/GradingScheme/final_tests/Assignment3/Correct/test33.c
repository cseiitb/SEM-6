void main(); main ()

{ int a;

do{ a = a + 1; } while(a>10);

}
