void main();

main ()
{
	int i;
	int f;
	
	while(i == 2)
	{
		i = f + (--i);
	}
}
