void main();

main()
{
	int i,j;

	do{
	i = i + 100 / i;
	j = i / 1000;
	}while(j==100);
}
