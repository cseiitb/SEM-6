void main();

main()
{
	float a,b,c,d;
	a = b + c;
        d = a;
        if(d==10.1)
        {
		d = 100.10;
	}
}

