void main();

main()
{
   	int n;
   	int sum , p;
   	n = 3;
	p = 10;
 
   	if ( (n/2) == n )	
      		sum = p;
   	else
      		sum = 11;
        if(sum == 2)
            sum = 2;
}
