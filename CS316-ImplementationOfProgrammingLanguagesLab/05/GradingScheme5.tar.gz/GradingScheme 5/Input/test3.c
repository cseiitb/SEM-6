void main();

main()
{
   int j;
   float a;
   float iftmp0;
   int m,n;

   a = 3.23;
   j = 5;
   while(a==3.23)
   {
       m = n + 5 / j;
       n = m *100 * j;
   }
}
