void main();

main ()
{
  int i1, i2, i3, i4;
  float f1, f2, f3, f4;
  i1 = 1;
  i2 = 2;
  i3 = 3;
  i4 = 4;
  while(i1 == i2)
  {
     while(i3==i4)
     {
         f1 = f2 + f3 / f4 * f1;
     }
  }
}


