void main();

main(){
  int a, b, x, y, t;
  x = 14;
  y = 36; 
 
  a = x;
  b = y;
 
  while (b != 0) {
    t = b / 100 - x - y;
  }
 
}
