void main();

main()
{
  	int c,a, n, fact;
  	fact = 1;
 	n = 5;
 	c = 1;
 	while(c <= n){
	fact = fact * c;
		c = c + 1;
 	}
	a = c + 4;
        if(c == 2)
          c = 10;
}
