void main();

main()
{
	int a, b, c, d, e, f, g, h;
	a = 3;
	b = 4;
	c = 5;
	d = a / (b + c);
	e = a / b + c;
	f = (a + b) / c;
	if(f == 2)
           a = 10;
	g = a + (b - c);
	h = (a + b) * c / (e - f);
}
