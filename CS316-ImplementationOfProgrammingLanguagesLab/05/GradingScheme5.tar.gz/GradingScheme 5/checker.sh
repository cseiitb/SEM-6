#!/usr/bin/env bash

for i in *.tar.gz
do
	echo -n "Press enter to go to $i folder else press another key  "
	read tmp
	if [[ "$tmp" == "" ]]; then
		tar -zxf "$i"
		echo "Extracted ${i%.tar.gz}"
		cd "${i%.tar.gz}"
        make		
		echo 'Compiled Successfully!'
		echo 'Checking test_cases  '
		for j in ../Input/*.c 
		do
			echo -n "Press 'y' to check $j  "
			read tmp2
			if [[ "$tmp2" == "y" ]]; then
				echo
				echo "Checking $j"
				./sclp -icode $j

				mv -f "$j.ast" "${j%.ast}.ans.ast" 2>/dev/null
			
				k=`echo $j |sed 's/Input/Answer/i'`
				# echo "$k"
				echo diff -bw "$j.dce" "$k.ic"
				diff -bw "$j.dce" "$k.ic"
				echo "------------------------------------------------------------------------------"
				rm -f "$j".*
			fi
		done
		echo 'test cases checked!'

		echo 'If you dont want to go through the code press a key'
		read tmp
		make clean
		cd ../
                rm -rf "${i%.tar.gz}"
		echo
	fi
done
