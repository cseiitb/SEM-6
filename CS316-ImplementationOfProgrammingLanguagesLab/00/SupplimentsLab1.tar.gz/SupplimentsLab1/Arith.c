main()
{
	int a = 1111111111;
	int f = 2, g = 8;

	a = a + f - g;
}
