/*******************************************************************************
			   Interpreter test file

				LocGlobSame.c
				-------------
			Local and global variable is same

This test file demonstrates the way sclp handles the situations where a local and a global variable name is same.
*******************************************************************************/

int a;

main()
{
	int a;		// Global and local variable 'a' name is same
	int b, c, d;
	a = 3;
	c = 5;
	b = a;
	a = c;
}
