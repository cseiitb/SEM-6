/***************************************************************************
			Interpreter + Compiler test file

				      Fact.c
				      ------
				Factorial of a number

This test file calculates the factorial of a number
***************************************************************************/

main()
{
  int c, n, fact = 1;
 
  n = 5;
 
  for (c = 1; c <= n; c++)
    fact = fact * c;
 
  return;
}
