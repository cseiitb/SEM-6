
#include <string>
#include <iostream>

using namespace std;

#include "common-classes.hh"
#include "user-options.hh"
#include "error-display.hh"
#include "user-options.hh"
#include "symbol-table.hh"
#include "ast.hh"
#include "procedure.hh"
#include "program.hh"

Symbol_Table::Symbol_Table()
{
	start_offset_of_first_symbol = 0;
	size_in_bytes = 0;
}

Symbol_Table::~Symbol_Table()
{}

void Symbol_Table::set_table_scope(Table_Scope list_scope)
{
	scope = list_scope;

	list<Symbol_Table_Entry *>::iterator i;
	for(i = variable_table.begin(); i != variable_table.end(); i++)
		(*i)->set_symbol_scope(list_scope);
}

Table_Scope Symbol_Table::get_table_scope()
{
	return scope;
}

bool Symbol_Table::is_empty()
{
	return variable_table.empty();
}

void Symbol_Table::push_symbol(Symbol_Table_Entry * variable)
{
	variable_table.push_back(variable);
}

void Symbol_Table::global_list_in_proc_check()
{
	list<Symbol_Table_Entry *>::iterator i;
	for (i = variable_table.begin(); i != variable_table.end(); i++)
	{
		string name = (*i)->get_variable_name();
		CHECK_INPUT((program_object.variable_proc_name_check(name) == false),
			"Global variable should not match procedure name", NO_FILE_LINE);
	}
}

bool Symbol_Table::variable_in_symbol_list_check(string variable)
{
	list<Symbol_Table_Entry *>::iterator i;
	for (i = variable_table.begin(); i != variable_table.end(); i++)
	{
		if ((*i)->get_variable_name() == variable)
			return true;
	}

	return false;
}

Symbol_Table_Entry & Symbol_Table::get_symbol_table_entry(string variable_name)
{
	list<Symbol_Table_Entry *>::iterator i;
	for (i = variable_table.begin(); i != variable_table.end(); i++)
	{
		if ((*i)->get_variable_name() == variable_name)
			return **i;
	}

	CHECK_INVARIANT(CONTROL_SHOULD_NOT_REACH, "The variable symbol entry doesn't exist");
}

/////////////////////////////////////////////////////////////

Symbol_Table_Entry::Symbol_Table_Entry()
{
	variable_data_type = void_data_type;

	start_offset = end_offset = 0;
	register_description = NULL;

}

Symbol_Table_Entry::Symbol_Table_Entry(string & name, Data_Type new_data_type, int line)
{
	variable_name = name;
	variable_data_type = new_data_type;

	lineno = line;

	start_offset = end_offset = 0;
	register_description = NULL;
}

Symbol_Table_Entry::~Symbol_Table_Entry()
{}

bool Symbol_Table_Entry::operator==(Symbol_Table_Entry & entry)
{
	if (variable_name != entry.get_variable_name())
		return false;
	else if (variable_data_type != entry.get_data_type())
		return false;
	else if (scope != entry.get_symbol_scope())
		return false;

	return true;
}

void Symbol_Table_Entry::set_symbol_scope(Table_Scope sp)
{
	scope = sp;
}

Table_Scope Symbol_Table_Entry::get_symbol_scope()
{
	return scope;
}

int Symbol_Table_Entry::get_lineno()
{
	return lineno;
}

Data_Type Symbol_Table_Entry::get_data_type()
{
	return variable_data_type;
}

void Symbol_Table_Entry::set_data_type(Data_Type dt)
{
	variable_data_type = dt;
}

string Symbol_Table_Entry::get_variable_name()
{
	return variable_name;
}
