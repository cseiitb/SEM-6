
#include <string>
#include <fstream>
#include <iostream>

using namespace std;

#include "common-classes.hh"
#include "error-display.hh"
#include "user-options.hh"
#include "symbol-table.hh"
#include "ast.hh"
#include "procedure.hh"
#include "program.hh"

Procedure::Procedure(Data_Type proc_return_type, string proc_name, int line)
{
	return_type = proc_return_type;
	name = proc_name;

	lineno = line;
}

Procedure::~Procedure()
{
	delete sequence_ast;
}

string Procedure::get_proc_name()
{
  return name;
}

void Procedure::set_sequence_ast(Sequence_Ast & sast)
{
  sequence_ast = &sast;
}

void Procedure::set_local_list(Symbol_Table & new_list)
{
	local_symbol_table = new_list;
	local_symbol_table.set_table_scope(local);
}

Data_Type Procedure::get_return_type()
{
	return return_type;
}

bool Procedure::variable_in_symbol_list_check(string variable)
{
	return local_symbol_table.variable_in_symbol_list_check(variable);
}

Symbol_Table_Entry & Procedure::get_symbol_table_entry(string variable_name)
{
	return local_symbol_table.get_symbol_table_entry(variable_name);
}

void Procedure::print(ostream & file_buffer)
{
	CHECK_INVARIANT((return_type == void_data_type), "Only void return type of funtion is allowed");

	file_buffer << PROC_SPACE << "Procedure: " << name << ", Return Type: void\n";

	sequence_ast->print(file_buffer);
}