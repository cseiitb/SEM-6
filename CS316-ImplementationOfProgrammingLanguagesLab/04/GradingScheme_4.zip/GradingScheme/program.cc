#include <string>
#include <fstream>

using namespace std;

#include "common-classes.hh"
#include "user-options.hh"
#include "error-display.hh"
#include "symbol-table.hh"
#include "ast.hh"
#include "procedure.hh"
#include "program.hh"

Program program_object;

Program::Program()
{}

Program::~Program()
{}

void Program::delete_all()
{
	delete procedure;
}

void Program::set_global_table(Symbol_Table & new_global_table)
{
	global_symbol_table = new_global_table;
	global_symbol_table.set_table_scope(global);
}

void Program::set_procedure(Procedure * proc, int line)
{
	CHECK_INVARIANT((proc != NULL), "Procedure cannot be null");

	procedure = proc;
}

bool Program::variable_proc_name_check(string symbol)
{
	if ((procedure != NULL) && (procedure->get_proc_name() == symbol))
		return true;

	return false;
}

bool Program::variable_in_symbol_list_check(string variable)
{
	return global_symbol_table.variable_in_symbol_list_check(variable);
}

Symbol_Table_Entry & Program::get_symbol_table_entry(string variable_name)
{
	return global_symbol_table.get_symbol_table_entry(variable_name);
}

void Program::global_list_in_proc_check()
{
	global_symbol_table.global_list_in_proc_check();
}

void Program::print()
{
	ostream * file_buffer;

	command_options.create_ast_buffer();
	file_buffer = &(command_options.get_ast_buffer());

	*file_buffer << "Program:\n";

	procedure->print(*file_buffer);
}
