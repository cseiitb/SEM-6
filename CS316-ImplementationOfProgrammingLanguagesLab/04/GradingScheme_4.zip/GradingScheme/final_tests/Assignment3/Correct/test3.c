void main();

main()
{
   float j;
   float a;
   float iftmp0;

   a = 3.23;
   j = 5.68;
   a = -j * a / a - j;
   
   if(!(-j <= a)){iftmp0 = 1.00; if(!(iftmp0 < -a))a = a + 1.00; else j = -a - 1.00;}
   else iftmp0 = 0.00;

}
