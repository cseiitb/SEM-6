void main();

main()
{
	float f, g;
	f = -1e0;
	g = 1e1;
	if (f < g){}
}
