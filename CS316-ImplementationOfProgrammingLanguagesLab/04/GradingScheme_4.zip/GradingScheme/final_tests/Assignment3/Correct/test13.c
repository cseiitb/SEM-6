void main();

main()
{
	int c, b, a;
	if(a >= b) a = 2;
	else{
		if(a <= b) b = 2;
	}

}
