void main();

main()
{
	float f1;
	int i1, i2;
	int a, b, c, d;
	float e, f, g, h;

	f1 = 10.3;
	i1 = 10;
	i2 = 11;

	e = f + f1 + g;
	f = e - f1 - h;
	a = i1 / i2 / i1;
	b = a * c * d;
}
