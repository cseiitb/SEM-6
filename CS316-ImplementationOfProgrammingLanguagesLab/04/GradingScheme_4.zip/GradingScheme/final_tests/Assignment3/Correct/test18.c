void main();

main()
{
	float a;
	a = 10.0;
	while(a<=12.0){
		a=a+0.5;
	}
}

