void main(); main ()

{ 

int a;
{
  int b;
  a = 0;
  
}
}
