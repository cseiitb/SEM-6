void main();

main()
{
	int a;
	a = 3;
	if (a){ a = a - 1; }
}
