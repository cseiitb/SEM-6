void main(); 

main()

{int a,b;

a = 1.0-a;

}
