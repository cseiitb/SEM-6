void main();

main()

{float a,b;

a = 1-a;

}
