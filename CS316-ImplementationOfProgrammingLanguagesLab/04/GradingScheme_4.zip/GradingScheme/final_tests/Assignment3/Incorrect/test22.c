void main();

main()
{
	int a;
	int b, d;
	a = 2; b = 4; d = 10;	

	if (a >= -b && !(3.2 < b)) a = a + 1;
	else b = b + 1;
}
