void main();

main()
{
	int a;
	float b;
	a = 3;
	b = 2.3;	

	if (a == 0) a = 2;
	else if () b = 3.0;
	else
	{
		a = a + 2;
		b = b + 1.0;
	}
}
