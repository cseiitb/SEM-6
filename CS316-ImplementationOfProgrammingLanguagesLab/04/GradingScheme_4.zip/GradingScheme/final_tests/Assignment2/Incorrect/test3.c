int a;
int b;
float c;
float d;

void main(); main(){
	int e;
	int f;
	int g;
	c = 0.0;
	d = 1.0e2;
	a = 1;
	b = 2;
	e = 3;
	e = a + b - e;
	f = e;
	g = (f + e - a + b)*((f + e - a + b)*2);
	c = (c + d)*2.3 - d;
	d = c;
}