#include <string>
#include <fstream>

using namespace std;

#include "common-classes.hh"
#include "user-options.hh"
#include "error-display.hh"
#include "icode.hh"
#include "reg-alloc.hh"
#include "symbol-table.hh"
#include "ast.hh"
#include "procedure.hh"
#include "program.hh"

void Program::print_sym()
{
	ostream * file_buffer;

	command_options.create_symtab_buffer();
	file_buffer = &(command_options.get_symtab_buffer());

	*file_buffer << "Program:\n";

	*file_buffer << "\nGlobal Declarations:\n";
	global_symbol_table.print(*file_buffer);

	procedure->print_sym(*file_buffer);
}

void Program::compile()
{
	// set up machine details
	machine_desc_object.initialize_register_table();
	machine_desc_object.initialize_instruction_table();

	// assign offsets to global variables
	global_symbol_table.set_start_offset_of_first_symbol(0);
	global_symbol_table.assign_offsets();

	// compile the program by visiting each procedure
	procedure->compile();
	if(command_options.is_show_ic_selected())
	{
		ostream * file_buffer;
		command_options.create_ic_buffer();
		file_buffer = &(command_options.get_ic_buffer());

		procedure->print_icode(*file_buffer);
	}

	// print assembly language
	if (!((command_options.is_do_lra_selected() == true) && 
	(command_options.is_do_compile_selected() == false)))
		print_assembly();
}

void Program::print_assembly()
{
	command_options.create_output_buffer();
	ostream & file_buffer = command_options.get_output_buffer();

	if (!global_symbol_table.is_empty())
		file_buffer << "\n\t.data\n";

	global_symbol_table.print_assembly(file_buffer);

	// print each procedure
	procedure->print_assembly(file_buffer);
}
