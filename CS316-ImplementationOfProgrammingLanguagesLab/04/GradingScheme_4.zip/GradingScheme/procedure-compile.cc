

#include <string>
#include <fstream>
#include <iostream>

using namespace std;

#include "common-classes.hh"
#include "error-display.hh"
#include "user-options.hh"
#include "icode.hh"
#include "reg-alloc.hh"
#include "symbol-table.hh"
#include "ast.hh"
#include "procedure.hh"
#include "program.hh"

void Procedure::print_sym(ostream & file_buffer)
{
	CHECK_INVARIANT((return_type == void_data_type), "Only void return type of funtion is allowed");

	file_buffer << PROC_SPACE << "Procedure: " << name << ", Return Type: void\n";

	file_buffer << "   Local Declarartions\n";
	local_symbol_table.print(file_buffer);
}

void Procedure::compile()
{
	// assign offsets to local symbol table
	local_symbol_table.set_start_offset_of_first_symbol(4);
	local_symbol_table.assign_offsets();

	// compile the program by visiting each sequence ast
	machine_desc_object.validate_init_local_register_mapping();
  	sequence_ast->compile();  	
	machine_desc_object.clear_local_register_mappings();

}

void Procedure::print_icode(ostream & file_buffer)
{
	file_buffer << "  Procedure: " << name << "\n";
	file_buffer << "  Intermediate Code Statements\n";
	
  sequence_ast->print_icode(file_buffer);
}

void Procedure::print_assembly(ostream & file_buffer)
{
	print_prologue(file_buffer);

  sequence_ast->print_assembly(file_buffer);

	print_epilogue(file_buffer);
}

void Procedure::print_prologue(ostream & file_buffer)
{
	stringstream prologue;

	prologue << "\n\
	.text \t\t\t# The .text assembler directive indicates\n\
	.globl " << name << "\t\t# The following is the code (as oppose to data)\n";

	prologue << name << ":\t\t\t\t# .globl makes main know to the \n\t\t\t\t# outside of the program.\n\
# Prologue begins \n\
	sw $fp, 0($sp)\t\t# Save the frame pointer\n\
	sub $fp, $sp, 4\t\t# Update the frame pointer\n";

	int size = local_symbol_table.get_size();
	size = -size;
	if (size > 0)
		prologue << "\n\tsub $sp, $sp, " << (size + 4) << "\t\t# Make space for the locals\n";
	else
		prologue << "\n\tsub $sp, $sp, 4\t\t#Make space for the locals\n";

	prologue << "# Prologue ends\n\n";

	file_buffer << prologue.str();
}

void Procedure::print_epilogue(ostream & file_buffer)
{
	stringstream epilogue;

	int size = local_symbol_table.get_size();
	size = -size;
	if (size > 0)
		epilogue << "\n# Epilogue Begins\n\tadd $sp, $sp, " << (size + 4) << "\n";
	else
		epilogue << "\n#Epilogue Begins\n\tadd $sp, $sp, 4\n";

	epilogue << "\tlw $fp, 0($sp)  \n\tjr        $31\t\t# Jump back to the operating system.\n# Epilogue Ends\n\n";

	file_buffer << epilogue.str();
}
