#!/usr/bin/env bash

for i in *.tar.gz
do
	echo -n "Press enter to go to $i folder else press another key  "
	read tmp
	if [[ "$tmp" == "" ]]; then
		tar -zxf "$i"
		echo "Extracted ${i%.tar.gz}"
		cp "${i%.tar.gz}"/parser.yy ./
		cp "${i%.tar.gz}"/scanner.ll ./		
		cp "${i%.tar.gz}"/ast.cc ./
		cp "${i%.tar.gz}"/icode.cc ./
		cp "${i%.tar.gz}"/icode.hh ./
		cp "${i%.tar.gz}"/ast-compile.cc ./
		cp "${i%.tar.gz}"/ast.cc ./

                make
		
		echo 'Compiled Successfully!'
		echo 'Checking test_cases for assignment1 ... '
		for j in final_tests/Assignment1/Correct/*.c 
		do
			echo -n "Press 'y' to check $j  "
			read tmp2
			if [[ "$tmp2" == "y" ]]; then
				echo
				echo "Checking $j"
				./sclp16 -ast "$j"
				mv -f "$j.ast" "${j%.ast}.ans.ast" 2>/dev/null
				./sclp -ast "$j"
				echo diff -bw "$j.ast" "${j%.ast}.ans.ast"
				diff -bw "$j.ast" "${j%.ast}.ans.ast"
				echo "------------------------------------------------------------------------------"
				rm -f "$j".*
			fi
		done
                for j in final_tests/Assignment1/Incorrect/*.c 
		do
			echo -n "Press 'y' to check $j  "
			read tmp2
			if [[ "$tmp2" == "y" ]]; then
				echo
				echo "Checking $j"
				./sclp16 -ast "$j" 2> err_dump
				mv -f "$j.ast" "${j%.ast}.ans.ast" 2>/dev/null
				./sclp -ast "$j" 2> ans_err_dump
				echo diff -bw "$j.ast" "${j%.ast}.ans.ast"
				diff -bw "$j.ast" "${j%.ast}.ans.ast"
				echo "------------------------------------------------------------------------------"
				echo diff -bw "err_dump" "ans_err_dump"
				diff -bw "err_dump" "ans_err_dump"
                                echo "------------------------------------------------------------------------------"
                                rm -f "$j".*
                                rm -f err_dump ans_err_dump
			fi
		done
		echo 'Assignment1 test cases checked!'
		
                
                echo 'Checking test_cases for assignment2 ... '
		for j in final_tests/Assignment2/Correct/*.c 
		do
			echo -n "Press 'y' to check $j  "
			read tmp2
			if [[ "$tmp2" == "y" ]]; then
				echo
				echo "Checking $j"
				./sclp16 -ast "$j"
				mv -f "$j.ast" "${j%.ast}.ans.ast" 2>/dev/null
				./sclp -ast "$j"
				echo diff -bw "$j.ast" "${j%.ast}.ans.ast"
				diff -bw "$j.ast" "${j%.ast}.ans.ast"
				echo "------------------------------------------------------------------------------"
				rm -f "$j".*
			fi
		done
                for j in final_tests/Assignment2/Incorrect/*.c 
		do
			echo -n "Press 'y' to check $j  "
			read tmp2
			if [[ "$tmp2" == "y" ]]; then
				echo
				echo "Checking $j"
				./sclp16 -ast "$j" 2> err_dump
				mv -f "$j.ast" "${j%.ast}.ans.ast" 2>/dev/null
				./sclp -ast "$j" 2> ans_err_dump
				echo diff -bw "$j.ast" "${j%.ast}.ans.ast"
				diff -bw "$j.ast" "${j%.ast}.ans.ast"
				echo "------------------------------------------------------------------------------"
				echo diff -bw "err_dump" "ans_err_dump"
				diff -bw "err_dump" "ans_err_dump"
                                echo "------------------------------------------------------------------------------"
                                rm -f "$j".*
                                rm -f err_dump ans_err_dump
			fi
		done
                echo 'Assignment2 test cases checked!'
                
                echo 'Checking test_cases for assignment3 ... '
		for j in final_tests/Assignment3/Correct/*.c 
		do
			echo -n "Press 'y' to check $j  "
			read tmp2
			if [[ "$tmp2" == "y" ]]; then
				echo
				echo "Checking $j"
				./sclp16 -ast "$j"
				mv -f "$j.ast" "${j%.ast}.ans.ast" 2>/dev/null
				./sclp -ast "$j"
				echo diff -bw "$j.ast" "${j%.ast}.ans.ast"
				diff -bw "$j.ast" "${j%.ast}.ans.ast"
				echo "------------------------------------------------------------------------------"
				rm -f "$j".*
			fi
		done
                for j in final_tests/Assignment3/Incorrect/*.c 
		do
			echo -n "Press 'y' to check $j  "
			read tmp2
			if [[ "$tmp2" == "y" ]]; then
				echo
				echo "Checking $j"
				./sclp16 -ast "$j" 2> err_dump
				mv -f "$j.ast" "${j%.ast}.ans.ast" 2>/dev/null
				./sclp -ast "$j" 2> ans_err_dump
				echo diff -bw "$j.ast" "${j%.ast}.ans.ast"
				diff -bw "$j.ast" "${j%.ast}.ans.ast"
				echo "------------------------------------------------------------------------------"
				echo diff -bw "err_dump" "ans_err_dump"
				diff -bw "err_dump" "ans_err_dump"
                                echo "------------------------------------------------------------------------------"
                                rm -f "$j".*
                                rm -f err_dump ans_err_dump
			fi
		done
                echo 'Assignment3 test cases checked!'

		echo 'If you dont want to go through the code press a key'
		read tmp
		make clean
                rm -rf "${i%.tar.gz}" scanner.ll parser.yy ast.cc ast-compile.cc icode.hh icode.cc
		echo
	fi
done
