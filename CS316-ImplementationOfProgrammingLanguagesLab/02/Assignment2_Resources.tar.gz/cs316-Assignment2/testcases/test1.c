void main(); main ()
{
  int a;
  a + 6;
}

