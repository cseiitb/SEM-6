void main(); main ()
{
  float f;
  float e;
  float d;
  int c;
  int b;
  int a;
  a = 3;
  b = 4;
  c = 2;
  e = 1.0e+0;
  f = 0.0;
  d = 7.0e+0;
  a = 0.0;
}
