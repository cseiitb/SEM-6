int a;

void main();
main()
{
	int a;
	a = 3;
	a = 4;
	a = a + 9;
	a = a + 2;
}