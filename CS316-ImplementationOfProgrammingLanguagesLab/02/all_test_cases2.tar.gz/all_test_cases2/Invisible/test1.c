void main();
main(){
	float a;
	a = 1e2;
}