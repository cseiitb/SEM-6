void main();
main(){
	int a;
	int b;
	float c;
	c = a + b;
}