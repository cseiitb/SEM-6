void main(); main()
{
	int a;
	a = 3;
	2 = a;
}