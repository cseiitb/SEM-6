void main();
main
{
	int a;
	float b;
	a = 0;
	b = 0;
}