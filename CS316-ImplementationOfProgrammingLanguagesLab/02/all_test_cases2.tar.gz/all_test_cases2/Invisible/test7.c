void main();
main()
{
	int a;
	int b;
	int c;
	int d;
	int e;
	int f;
	int g;
	int h;
	int i;
	int j;
	int k;
	int l;
	int m;
	int n;
	int o;
	int p;
	float q;
	float r;
	float s;
	float t;
	float u;
	float v;
	float w;
	float x;
	float y;
	float z;

	a = 3;
	b = 4;
	c = 3;
	d = 4;
	e = 3;
	f = 4;
	g = 3;
	h = 4;
	i = 3;
	j = 4;
	k = 3;
	l = 4;
	m = 3;
	n = 4;
	q = 3.0;
	r = 4.0;
	s = 3.0;
	t = 4.0;
	u = 3.0;
	v = 4.0;
	w = 3.0;
	x = 4.0;
	y = 3.0;
	z = 4.0;

	a = b + c * (d / ((e * f) + (g - h) / i) / j + k * (l + m - n));
	q = (r / (s / (t / (u / (v / (w / (x / (y / z))))))));
}