void main();

main(){ 
  int Void;
  Void = 2;
}