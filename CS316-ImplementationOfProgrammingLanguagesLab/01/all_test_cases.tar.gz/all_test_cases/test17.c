void main();

main()
{
}
