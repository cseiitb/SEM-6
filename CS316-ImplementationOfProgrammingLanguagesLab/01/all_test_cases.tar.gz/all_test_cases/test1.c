void main();

main(){
  int a;
  int b;

  a=10;
  a=900;
  b=10;
  b=a;
  a=b;
}