int a;
void main();

main()
{
	int a;
	int b;
	int c;
	int d;
	a = 3;
	c = 5;
	b = a;
	a = c;
}
