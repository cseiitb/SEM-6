void main();

main(){
  int a_9;
  int a_8;

  a_9 = a_8 = 0;
}