void f();

f(){
  int void;
  int return;

  void = 2.3;
}