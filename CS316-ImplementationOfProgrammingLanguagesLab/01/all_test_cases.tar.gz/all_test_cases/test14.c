void main();
int _c;

main(){
  int a_;
  
  a_=10;
  a_= -900;
  _c=a_;
 }