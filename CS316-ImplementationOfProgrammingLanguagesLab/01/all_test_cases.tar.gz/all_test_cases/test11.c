void main();

main(){
  int INT;
  int INT2;

  INT=10;
  INT=900;
  INT2=10;
  INT2=INT;
  INT=INT2;
}