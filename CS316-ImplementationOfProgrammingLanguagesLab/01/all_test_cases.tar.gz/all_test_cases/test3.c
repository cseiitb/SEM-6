void main();

main(){
  int a_331d;
  int a_9_f@;

  a_331d=10;
  a_331d=900;
  a_331d=10;
  a_9_f@= 0;
}