int a;
void main();
int f(int c);

main()
{
	int a;
	a=1;
	a=f(a);
	print("a: ");
	print(a); 
	print("\n");	
	return;
}

f(int c)
{
	a=5;
	return c;
}
