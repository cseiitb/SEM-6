void main();

main()
{
	float a,b,c;
	a = 2.34;
	 b = 2.1;
	  c = 8.3;

	if (a + b / c / a * b <=3.0)
		a = a-1.0;
print("a: ");
  print(a); 
  print("\n");
	return;
}
