int fun1(int a, int b);
int fun2(int a);
void main();

main()
{
	int x,arg1,arg2;
	arg1=fun1(5,2);
	arg2=fun1(7, 3);
	x = fun1 (arg1, arg2 );
	print("x: ");
  print(x); 
  print("\n");
  return;
}

fun1(int a, int b)
{
	int x,g;
	x=a-b;
	g = fun2(x);
	return g;
} 

fun2(int a)
{
	return a*a;
}
