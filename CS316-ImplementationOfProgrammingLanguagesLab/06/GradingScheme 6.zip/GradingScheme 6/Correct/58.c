void main();

main()
{
int i1, i2;
i1 = 2; i2 = 3;

print(i1); print("\n");
print(i2); print("\n");

i1 = -(-i2);

print(i1); print("\n");

return;
}
