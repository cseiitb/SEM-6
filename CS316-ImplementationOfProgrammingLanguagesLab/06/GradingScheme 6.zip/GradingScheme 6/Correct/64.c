
void recurfn(int number);
int recurfactorial(int n);
void main(); 

main()

{
  int number;
  int fact;
  fact = 1;
  number = 5; 

  recurfn(number);
  return;
}

recurfn(int number)
{
  int fact;
  fact = recurfactorial(number);
  print(fact); print("\n");
  return;
}
 
recurfactorial(int n)
{
  int result ;
  int k;
  
  print(n); print("\n");
  if (n == 0){
    result = 1;
    print(result); print("\n");
  }
  
  else{

    result = recurfactorial(n-1);
    result = (n * result);
    print(result); print("\n");
  }
  return result;

}
