void main(); main ()

{ int a;
  a = 0;
do{ a = a + 1; } while(a>10);
print(a); print("\n");
return;
}
