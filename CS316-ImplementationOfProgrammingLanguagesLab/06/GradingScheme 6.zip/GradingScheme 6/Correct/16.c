int fn();
void main();

fn(){
	int a,b;
	a=63;
	b= 14578;
	return (a>b ? a*a+a : a-a*a);
}

main ()
{
	int a;
	a = fn();
	print("a: ");
	print(a); 
	print("\n");
	return;
}
