void main();
int fn(int a, int b);

fn(int a, int b)
{
	print("a: ");
	print(a); 
	print("\n");
	print("b: ");
	print(b); 
	print("\n");
   return a + b;
}

main()
{
   int a;
   a = 2;
   a = fn(a, a);
   	print("a: ");
	print(a); 
	print("\n");
	return;
}
