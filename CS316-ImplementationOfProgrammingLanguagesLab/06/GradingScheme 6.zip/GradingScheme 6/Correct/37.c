void main();

main()
{
	int a,b,c,d,e,f;
	a = 2;
	b = 4;
	c = 10;
	d = 3;
	e = 8;
	f = 7;

	if (a >= b + c / d + e - a - f)
		a = a+d * e / f / b;
	else
		b = 1;

	print("a: ");
  print(a); 
  print("\n");
  print("b: ");
  print(b); 
  print("\n");

	return;
}
