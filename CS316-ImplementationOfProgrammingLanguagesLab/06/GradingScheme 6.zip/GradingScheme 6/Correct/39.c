void main();

main()
{
   float f3;
   float f2;
   float f1;
   int i3;
   int i2;
   int i1;
   int iftmp0;

   f1 = 2.34;
   f2 = 4.5;
   if(f1 != 0.00)
   {
     if(f2 != 0.00)
        iftmp0 = 1;
     else
        iftmp0 = 0;
   }
   else
     iftmp0 = 0;
   i1 = iftmp0;

   print("iftmp0: ");
  print(iftmp0); 
  print("\n");
  print("i1: ");
  print(i1); 
  print("\n");

return;

}
