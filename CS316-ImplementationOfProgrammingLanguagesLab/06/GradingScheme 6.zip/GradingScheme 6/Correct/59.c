int a;
void main();
int f();

f()
{
        a = 10;
        print(a); print("\n");
        return 0;
}


main(){
	int a,b,c;
	a = 15;
        print(a); print("\n");
        f();
        return ;
}
