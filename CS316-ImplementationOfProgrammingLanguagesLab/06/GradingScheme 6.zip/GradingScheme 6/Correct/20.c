void main();

main()
{
	float a;
	a=10.3;
	while(a<=12.0){
		a=a+0.5;
		print("a: ");
  print(a); 
  print("\n");
	}
	return;
}

