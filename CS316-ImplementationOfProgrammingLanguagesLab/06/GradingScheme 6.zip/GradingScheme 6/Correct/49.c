void main();

main ()
{
	int i;
	float f;

        i = 4;
        f = 2.0;
	
	if (i < i + i / 2) f = 3.0;
	else{
		if (i + i >= i) f = 4.0;
		else{
			if ((i>3) && (i<7)) i = i+i;
			else	f = f+1.0;
		}
	}	
        
        print(i); print("\n");
        print(f); print("\n");

	return;
}
