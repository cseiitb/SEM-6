void main(); 

main()

{

   int a;
   int b;
   a = 10;
   b = 20;
   
   a = (a + b) + (a + b);
   b = a + b + a + b;
   
   print(a); print("\n");
   print(b); print("\n");
   return;
}

