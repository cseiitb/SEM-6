void main();

main()
{
	int a,b,d;
	a = 2;
	b = 4;
	d = 10;

	if (a >= -b)
		a = a+1;
	else
		b = b+1;

	print("a: ");
  print(a); 
  print("\n");

  print("b: ");
  print(b); 
  print("\n");
  return;
}
