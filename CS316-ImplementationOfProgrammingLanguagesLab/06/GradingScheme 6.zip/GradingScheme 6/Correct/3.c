int f(int a, int b);
void main();

f(int a, int b)
{
	if(a>b) return 1;
	else return 0;

	return -1;
}

main()
{
	int x;
	int y;
	int i;
	
    x=10;
	y=5;
	i=f(x,y);

 	print(x); print("\n");
	print(y); print("\n");
	print(i); print("\n");	
	return ;
}
