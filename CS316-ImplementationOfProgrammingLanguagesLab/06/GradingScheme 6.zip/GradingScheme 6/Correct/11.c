void main();

main()
{
	int i1,i2;
	i1=1; i2=2;
	i1 = -i1-i2;

	print("i1: ");
	print(i1); 
	print("\n");

	print("i2: ");
	print(i2); 
	print("\n");
	return;
}
