int factorial(int n);
int find_ncr(int n, int r);
int find_npr(int n, int r);
int main();

main()
{
   int n, r;
   int ncr, npr;
 
   n = 5;
   r = 3;
 
   ncr = find_ncr(n, r);
   npr = find_npr(n, r);
   print(ncr);print("\n");
   print(npr);print("\n"); 
 
   return 0;
}
 
find_ncr(int n, int r)
{
   int result;
   int t1,t2,t3;

   t1 = factorial(n);
   t2 = factorial(r);
   t3 = factorial(n-r);
   result = t1/(t2*t3);
 
   return result;
}
 
find_npr(int n, int r)
{
   int result;
   int t1,t2;
   
   t1 = factorial(n);
   t2 = factorial(n-r);
 
   result = t1/t2;
 
   return result;
} 
 
factorial(int n)
{
   int c;
   int result;
   
   result = 1;
   c = 1;
 
   while(c<=n){
      result = result*c;
      c = c + 1;
   }
   
   return result;
}
