void fun2();
void fun1();
void fun();
void main();

fun2()
{
	float a;
	a=-4.56;
	a=-a;
	print("a: ");
	print(a); 
	print("\n");
	return;
}


fun1()
{
fun2();
return;
}

fun()
{
fun1();
return;

}

main()
{
fun();
return;
}
