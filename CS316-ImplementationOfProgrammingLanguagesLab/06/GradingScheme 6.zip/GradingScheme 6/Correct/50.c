void main();

main ()
{
	int i;
	float f;
	
        i = 2;
        f = 2.0;
        
	i = 4;
	i = i>2 ? i-i*i : i/i+i;

        print(i); print("\n");
        print(f); print("\n");

	return;
}
