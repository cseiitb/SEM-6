void main();
int fact(int n);

fact(int n)
{
	int i;
	if (n == 0)
		return 1;

	i = fact(n - 1);
print("i: ");
print(i); 
print("\n");
	return n * i;
}

main()
{
	fact(5);
	return;
}
