void main();
	
main()
{
float a,b;
a = 6.0; b = 3.0;

print(a); print("\n");
print(b); print("\n");

a=a-b;
b=a+b;
a=b-a;

print(a); print("\n");
print(b); print("\n");
return;
}
