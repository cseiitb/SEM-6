void main();

main()
{	
	float a,b,c,g;
	a = 1.0;
	b = 2.0;
	c = 3.0;

	if (a>=b && a>=c) g=a;
	if (b>=a && b>=c) g=b;
	if (c>=a && c>=b) g=c;			
	
	print("g: ");
  print(g); 
  print("\n");		
			return;
}
