int a;
void main();
int fn();
void fn2();

main()
{
	int z;
	fn2();
	z = fn();
	print("z: ");
  print(z); 
  print("\n");
  return;
}

fn2()
{
	a = 678;
	return;
}

fn()
{
	return a;
}
