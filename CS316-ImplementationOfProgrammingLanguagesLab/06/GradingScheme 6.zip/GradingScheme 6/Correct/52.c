void main();

main()
{
  	int c, n, fact;
  	fact = 1;
 	n = 5;
 	c = 1;
 	while(c <= n){
	fact = fact * c;
		c = c + 1;
                print(c); print("\n");
 	}
        
        print(fact); print("\n");
 	return;
}
