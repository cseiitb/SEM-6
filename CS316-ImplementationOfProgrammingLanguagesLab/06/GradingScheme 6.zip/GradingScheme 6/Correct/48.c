void main();

main()
{
	int c, b, a;
        
        a = 1; b = 2; c = 3;
        
	if(a >= b) a = 2;
	else{
		if(a <= b) b = 8;
	}

        print(a); print("\n");
        print(b); print("\n");
        print(c); print("\n");
        
	return;
}
