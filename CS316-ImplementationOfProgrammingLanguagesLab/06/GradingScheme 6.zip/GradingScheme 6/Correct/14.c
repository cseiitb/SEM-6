void main();

main()
{
	int  a,b,c;
	a = 2;
	b = 3;
	c = 4;

	a = -(c * b);

	print("a: ");
	print(a); 
	print("\n");

	return;
}
