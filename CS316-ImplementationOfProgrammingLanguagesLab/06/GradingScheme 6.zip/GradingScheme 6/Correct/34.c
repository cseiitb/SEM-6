void main();

main()
{
	int a,b,c;
	a = 3;
	 b = 5;
	  c = 10;

	if (a + b * c / a / b > 3)
		a = a+1;
	print("a: ");
  print(a); 
  print("\n");
	return;
}
