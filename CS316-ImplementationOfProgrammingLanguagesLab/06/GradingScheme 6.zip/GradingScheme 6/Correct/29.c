int a;
void main();
int fn(int a);

fn(int a)
{
   return a;
}

main()
{
   int b,c;
   b = 3;
   a=6;
   c = fn(b);
   print("c: ");
  print(c); 
  print("\n");
  return;
}

