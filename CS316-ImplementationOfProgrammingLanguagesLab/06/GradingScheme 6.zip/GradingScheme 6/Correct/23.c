int fn();
void main();

main()
{
	int a ;
	a= 5;
	a = fn();
	print("a: ");
  print(a); 
  print("\n");
  return;
}

fn()
{
	int e;
	e = 10;
	return e;
}
