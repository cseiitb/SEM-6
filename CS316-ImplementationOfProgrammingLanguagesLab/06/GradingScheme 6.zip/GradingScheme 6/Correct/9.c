void main();

main()
{
	int a,b,c,d,e,f,g,h;
	a = 3;
	 b = 4;
	  c = 5;
	d = a / (b + c);
	 e = a / b + c;
	 f = (a + b) / c;
	 g = a + (b - c);
	 h = (a + b) * c / ((e - f) + (a - b));


	print("d: ");
	print(d); 
	print("\n");
	print("e: ");
	print(e); 
	print("\n");
	print("f: ");
	print(f); 
	print("\n");
	print("g: ");
	print(g); 
	print("\n");
	print("h: ");
	print(h); 
	print("\n");
	return;
}
