void main();

main()
{
   int i1;
   float f1;

   i1 = 3;
   f1 = 2.53;

   if(f1 < 5.00 )
   {
      i1 = i1 + i1;
      f1 = f1 + 1.00;
   }


print("f1: ");
  print(f1); 
  print("\n");

  print("i1: ");
  print(i1); 
  print("\n");

   return;
}
