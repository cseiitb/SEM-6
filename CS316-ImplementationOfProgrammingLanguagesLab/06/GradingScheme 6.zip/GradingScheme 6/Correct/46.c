void main();

main()
{
	float f1;
	int i1, i2;
	int a, b, c, d;
	float e, f, g, h;

	f1 = 10.3;
	i1 = 10;
	i2 = 11;
        f = 1.0;
        g = 2.0;
        e = 3.0;
        h = 4.0;
        a = 1;
        c = 2;
        d = 3;

	e = f + f1 + g;
	f = e - f1 - h;
	a = i1 / i2 / i1;
	b = a * c * d;
        
        print(e); print("\n");
        print(f); print("\n");
        print(a); print("\n");
        print(b); print("\n");
        
	return;
}
