
void main();

main()
{
   float x;
   float y;
   float z;

   x = 5.50;
   y = 1.10;
   z = 1.20;
   z = -z * y + x;
   z = x + y - x;
   
   print("x: "); print(x); print("\n");
print("y: "); print(y); print("\n");
print("z: "); print(z); print("\n");   

return;

}

