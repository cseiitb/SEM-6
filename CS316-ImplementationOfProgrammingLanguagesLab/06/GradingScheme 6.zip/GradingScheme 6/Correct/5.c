void fun();
void main();
void g();
int i;

main()
{
    g();
    while(i != 0)
    {
    	print("i: ");
        print(i); 
        print("\n");
        fun();
    }
    return ;
}
fun()
{
    i = i-1;
    return ;
}

g()
{
	i=10;
    return;
}
