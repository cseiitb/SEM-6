void main();

main()
{
	int a;
	int f,g;
	a = 1111111111;
	f = 2;
	g = 8;

	a = a + f - g;
	print("a: ");
	print(a); 
	print("\n");
	return;
}
