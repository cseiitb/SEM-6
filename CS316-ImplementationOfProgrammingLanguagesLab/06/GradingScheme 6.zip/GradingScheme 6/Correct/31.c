int a;
int fn(int b);
void main();

fn(int b)
{
   return b;
}

main()
{
   int a,b;
   a = 3;
   b = fn(a);
   print("b: ");
  print(b); 
  print("\n");
   return;
}

