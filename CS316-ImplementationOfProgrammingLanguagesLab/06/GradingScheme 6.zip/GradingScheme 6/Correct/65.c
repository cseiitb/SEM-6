int size;
int i;
int prev_number;
int number;
int fibonacci(int prev_number, int number);
void main();

main()
{
    prev_number=0;
    number=1;
    size = 20;
    i = 1;
    fibonacci (prev_number,number);
    
    return ;
}

fibonacci (int prev_number, int number)
{
    int next_num;
  
    print(prev_number); print(" "); print(number); print("\n");
    
    if (i==size) return 0;
    else
    {
      next_num=prev_number+number;
      prev_number=number;
      number=next_num;
      i = i + 1; // increment counter
      fibonacci (prev_number,number); //recursion
    }
    
    return 0;
}
