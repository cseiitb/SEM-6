int f(int a);
int g(int a);
int h(int a,int b);
void main();

main(){
	int a;
	int b;
	a=10;
	b = f(a);
	a = g(a);
	a=h(b,a);
	print("a: ");
  print(a); 
  print("\n");
	return;
}

f(int a){
	return a+1;
}

g(int a){
	return a-4;
}

h(int a, int b){
	return a*b;
}
