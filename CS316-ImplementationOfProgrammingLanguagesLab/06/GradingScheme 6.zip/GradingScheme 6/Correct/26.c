int f(int a);
void main();

main(){
	int x, i;
	x=0;
	i = 0;
	while(i<10){
		x=f(x);
		print("x: ");
  print(x); 
  print("\n");
		i = i+1;
	}
	return;
}

f(int a){
	a=(a+1)*2;
	return a;
}
