void main();
// void fn2();

// fn2 ()
main ()
{
  float iftmp1;
  int iftmp0, i1, i2, i3, i4;
  float f1, f2, f3, f4;

  i1 = 2;
  f1 = 3.2;
  i2 = 4;
  f2 = 5.6;
  iftmp1 = 0.0;
  iftmp0 = 0;
  
  print(i1); print("\n");
  print(f1); print("\n");
  print(i2); print("\n");
  print(f2); print("\n");
  print(iftmp1); print("\n");
  print(iftmp0); print("\n");
  
  if (f1 == f2)
    iftmp1 = 1.0;
  else
    iftmp1 = 0.0;

  f1 = iftmp1;
  f3 = f1 + f2;
  if (i1 != 0)
  {
     if (f2 != 0.0)
        iftmp0 = 1;
     else
  	iftmp0 = 0;
  }
  else
    f2 = 0.0;

  f2 = iftmp1;

  print(i1); print("\n");
  print(f1); print("\n");
  print(i2); print("\n");
  print(f2); print("\n");
  print(iftmp1); print("\n");
  print(iftmp0); print("\n");

  return;
}


