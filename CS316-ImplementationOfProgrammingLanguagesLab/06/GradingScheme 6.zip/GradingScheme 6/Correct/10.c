void main();

main()
{
	float a,b,c;
	a = 2.3;
	b = 3.4;
	c = a * b / a;

	print("c: ");
	print(c); 
	print("\n");
	return;
}
