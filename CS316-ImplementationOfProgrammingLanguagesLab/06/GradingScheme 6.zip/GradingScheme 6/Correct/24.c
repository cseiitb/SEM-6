int fn(int a);
int fn1(int a);
void main();

main()
{
	int a;
	a = 3;
	a = fn (a);
print("a: ");
  print(a); 
  print("\n");
	return;
}

fn(int a)
{
	a = a + 1;
	print("a: ");
  print(a); 
  print("\n");
	return fn1(a);
}

fn1(int a)
{
	a = a * a;
	print("a: ");
  print(a); 
  print("\n");
	return a;
}
