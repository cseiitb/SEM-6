
void main();

main()
{
   int a;
   int b;
   int c;
   int d;

   a = 5;
   b = -a;
   d = a + 2;
   c = a + b;
   c = a - b;
   c = a * b;
   c = a / b;
   
   print("a: ");
   print(a); 
   print("\n");

   print("b: ");
   print(b); 
   print("\n");
 
   print("c: ");
   print(c); 
   print("\n");

   print("d: ");
   print(d); 
   print("\n");
   
   return;

}

