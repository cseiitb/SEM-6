int a;
void main();
void fn();

main()
{
	a = 10;
	print("a: ");
  print(a); 
  print("\n");
	fn();
	print("a: ");
  print(a); 
  print("\n");
  return;
}

fn()
{
	int a;
	a = 6;
	return;
}
