void main();

main()
{
   int d;
   int c;
   float b,a;

   a = 5.2;
   b = 10.0;
   if(a==b){
      c = 4;
   } else {
      c=6;
   }
   
   print(c); print("\n");
   return ;
}
