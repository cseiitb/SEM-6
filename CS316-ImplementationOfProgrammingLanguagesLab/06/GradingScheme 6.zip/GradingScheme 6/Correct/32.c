int a;
void main();
void fn();

main()
{
	a = 3;
	print("a: ");
  print(a); 
  print("\n");
	fn();
	print("a: ");
  print(a); 
  print("\n");
	a = 4;
	print("a: ");
  print(a); 
  print("\n");
  return;
}

fn()
{
	a = 10;
	return;
}
