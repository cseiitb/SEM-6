int fn();
void main();

fn(){
	int a;
	int D1234;
	D1234 = 3;
	a=2;

	if (a > 5)
		return D1234;
	else
		return a;
	return 1;
}

main()
{
	int a;
	a = fn();
	print("a: ");
	print(a); 
	print("\n");
	return;
}
