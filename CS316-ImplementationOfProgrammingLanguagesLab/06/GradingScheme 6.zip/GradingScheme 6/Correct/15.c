int fn();
void main();


main()
{
	int a;
	a = fn();
	print("a: ");
	print(a); 
	print("\n");
	return;
}

fn()
{
	return 3;
}
