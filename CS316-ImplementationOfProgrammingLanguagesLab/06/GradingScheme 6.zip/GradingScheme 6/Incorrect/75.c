int hgk;

int f1(int a, int b);
int f2();
int main();

f1(int a){
	return 2;
}

f2(){
	return 2000;
}

main(){
	int a,b,c;
	float d;
        hgk = 1000;
	a = f1(0);
        b = f1(100);
        c = f2();
        
        print(a); print("\n");
        print(b); print("\n");
        print(c); print("\n");
        
	return 0;	
}
