
void nonrecurfn(int n);
int nonrecurfactorial(int n);
void main(); 

main()

{
  int number;
  int fact;
  fact = 1;
  number = 5; 

  print(fact); print("\n");
  print(number); print("\n");

  nonrecurfn(number); 
  return;
}

nonrecurfactorial(int n)
{
  int c;
  int result;
  result = 1;
  c = 1;
  while ( c <= n){
    result = result * c;
    c = c+1;
 }
  return 1.0;
}

nonrecurfn(int n)
{
  int f;
  
  print(n); print("\n");
  if (n < 0){ print("END"); print("\n"); }
  else
  {
   f = nonrecurfactorial(n);
  }
 
  print(f); print("\n");
  return 0;
}
