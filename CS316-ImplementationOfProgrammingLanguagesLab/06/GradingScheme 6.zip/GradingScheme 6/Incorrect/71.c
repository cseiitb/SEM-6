int fn(int a, int b);		// 2 parameters
void main();

main()
{
	int a;
	a = 3;
	fn (3.3, 3);
	return 0;		// Doesn't match the return value in the 
				// prototype
}

fn(float a)			// 1 parameter. Different from its prototype
				// Data type of variable 'a' is float, 
				// different from its prototype
{
	return 2;
}
