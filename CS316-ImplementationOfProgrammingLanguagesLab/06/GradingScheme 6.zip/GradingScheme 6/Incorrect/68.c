int fn(int a);
float fn(float b);	// Function name 'fn' used for more than 1 function
void main();

main()
{
	int a;
	a = 3;
	fn(a);
	fn(2.3);
	return;
}

fn(int a)
{
	return 3;
}

fn(float b)
{
	return 2.3;
}
