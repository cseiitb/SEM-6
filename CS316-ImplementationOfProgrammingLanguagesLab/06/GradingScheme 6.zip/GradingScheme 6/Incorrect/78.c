int from_tower;
int to_tower;

void TOH(int n, int n,int TOH,int z);
void main();

main()
{
 int n;
 n = 5;
 TOH(n-1,10,20,30);

 return;
}

TOH(int n,int n,int TOH,int z)
{
  float z;
 print(n); print(" "); print(x); print(" "); print(y); print(" "); print(z); print("\n"); 
 
 if(n>0)
 {
  TOH(n-1,x,z,y);
  from_tower = x;
  to_tower = y;
  TOH(n-1,z,y,x);
 }

 return;
}
