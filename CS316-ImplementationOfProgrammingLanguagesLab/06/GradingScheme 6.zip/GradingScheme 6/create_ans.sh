for j in Correct/*.c 
do
	# echo -n "Press 'y' to check $j  "
	# read tmp2
	# if [[ "$tmp2" == "y" ]]; then
		echo
		echo "Checking $j"
		echo  "./sclp16 $j"
		./sclp16 $j
		k=`echo $j |sed 's/Correct/Answer/i'`
		echo "spim -file '$j.s' | tail -n +6 > '$k.ans'"
		spim -file "$j.s" | tail -n +6 > "$k.ans"
		mv -f "$j.ast" "${j%.ast}.ans.ast" 2>/dev/null
		echo "------------------------------------------------------------------------------"
		rm -f "$j".*
	# fi
done
echo 'test cases checked!'