for i in 4 8 16 32 64 128
do
python neural-network.py $i
done
